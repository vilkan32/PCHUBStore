﻿function remove() {

    document.getElementById('closeVideoPlayer').addEventListener('click', function () {
        document.getElementById('videoPlayer').style.display = 'none';
    });
}


remove();